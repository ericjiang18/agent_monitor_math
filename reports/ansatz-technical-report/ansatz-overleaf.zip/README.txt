Compile main.tex with pdfLaTeX in Overleaf.
The entire document is self-contained; no images, .sty, or .bib files are needed.
Title/authors: Math Framework LLM Assistant For Research; Richard C, Eric J.
Revised 20 September 2026 to follow the supplied mentor's template.
Section 6.4 adds a saved solved sqrt(8) irrationality example with Lean evidence.
The original 15 September checks and the 16 September measurements retain their dates.
Supporting evidence is in the companion repository report directory.
