Compile main.tex with pdfLaTeX. This file embeds its TikZ diagram and bibliography. No other files are required. Set author names and affiliations before submission.
